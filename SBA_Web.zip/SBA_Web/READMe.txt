 This application is designed to mimic real world ecomerce website
 The website consists of five pages: Home, product, about, contact, account.
Home: The main page. It displays the general overview of the company and some of the products
Product: Consists of all the available products
About: This page is not implemented yet...
Contact: Displays the contact info of our company stuff/members 
Account: This page is designed for the user to create an account or login for the existing users.

