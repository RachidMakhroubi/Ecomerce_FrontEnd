/**
 Registration page
 */
function registration() {
  var name = document.querySelector("#username").value;
  var email = document.querySelector("#email").value;
  var pwd = document.querySelector("#pass").value;
  var cpwd = document.querySelector("#confirmPass").value;

  //email id expression code
  var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
  var letters = /^[A-Za-z]+$/;
  var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

  if (name == '') {
    alert('Please enter your name');
  }
  else if (!letters.test(name)) {
    alert('Name field required only alphabet characters');
  }
  else if (email == '') {
    alert('Please enter your user email id');
  }
  else if (!filter.test(email)) {
    alert('Invalid email');
  }

  else if (pwd == '') {
    alert('Please enter Password');
  }
  else if (cpwd == '') {
    alert('Enter Confirm Password');
  }
  else if (!pwd_expression.test(pwd)) {
    alert('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
  }
  else if (pwd != cpwd) {
    alert('Password not Matched');
  }
  else if (document.getElementById("pass").value.length < 6) {
    alert('Password minimum length is 6');
  }
  else if (document.getElementById("pass").value.length > 12) {
    alert('Password max length is 12');
  }
  else {
    alert('Thank You for Registration & You are Redirecting to Website');
    // Redirecting to other page or webste code. 
  }

}

var LoginForm = document.getElementById("LoginForm")
var RegisterForm = document.getElementById("RegisterForm")
var indicator = document.getElementById("indicator")

function login() {
  RegisterForm.style.transform = "translateX(300px)";
  LoginForm.style.transform = "translateX(300px)";
  indicator.style.transform = "translateX(0px)"

}

function register() {
  RegisterForm.style.transform = "translateX(0px)";
  LoginForm.style.transform = "translateX(0px)";
  indicator.style.transform = "translateX(100px)"
}


var darkIcon = document.getElementById("darkModIcon");
var lightIcon = document.getElementById("lightModIcon");
darkIcon.onclick = function () {
  const boxes = document.querySelectorAll('.header');
  boxes.forEach(box => {
    box.style.background = 'black';
    box.style.color = "black";
  });

  var all = document.getElementsByTagName("*");
  for (var i = 0, max = all.length; i < max; i++) {
    all[i].style.color = "white";
  }
  document.querySelector("#lightModIcon").style.background = 'white';
}


lightIcon.onclick = function () {
  const boxes = document.querySelectorAll('.header');
  boxes.forEach(box => {
    box.style.background = "cornsilk";

  });
  var all = document.getElementsByTagName("*");
  for (var i = 0, max = all.length; i < max; i++) {
    all[i].style.color = "black";
  }
}